public class Main {

    public static void main(String[] args) {
        // Create a user with valid data
        User user = new User("Ahlomela", "Smith", "kyl_1", "Ch&8&sec@ke99!", "+27839668976");

        // Registration output
        System.out.println(user.Main());

        // Login attempts
        System.out.println(user.returnLoginStatus("kyl_1", "Ch&8&sec@ke99!")); // Correct login
        System.out.println(user.returnLoginStatus("wrong", "password"));       // Incorrect login
    }
}

}
