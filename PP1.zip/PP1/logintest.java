public class logintest {
    import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

    public class UserTest {

        @Test
        public void testValidUsername() {
            User user = new User("Ahlomela", "Smith", "kyl_1", "Ch&8&sec@ke99!", "+27839668976");
            assertTrue(user.checkUserName());
        }

        @Test
        public void testInvalidUsername() {
            User user = new User("Ahlomela", "Smith", "ke99", "Ch&8&sec@ke99!", "+27839668976");
            assertFalse(user.checkUserName());
        }

        @Test
        public void testValidPassword() {
            User user = new User("Ahlomela", "Smith", "kyl_1", "Ch&8&sec@ke99!", "+27839668976");
            assertTrue(user.checkPasswordComplexity());
        }

        @Test
        public void testInvalidPassword() {
            User user = new User("Ahlomela", "Smith", "kyl_1", "password", "+27839668976");
            assertFalse(user.checkPasswordComplexity());
        }

        @Test
        public void testValidCellPhone() {
            User user = new User("Ahlomela", "Smith", "kyl_1", "Ch&8&sec@ke99!", "+27839668976");
            assertTrue(user.checkCellPhoneNumber());
        }

        @Test
        public void testInvalidCellPhone() {
            User user = new User("Ahlomela", "Smith", "kyl_1", "Ch&8&sec@ke99!", "08965553");
            assertFalse(user.checkCellPhoneNumber());
        }

        @Test
        public void testLoginSuccess() {
            User user = new User("Ahlomela", "Smith", "kyl_1", "Ch&8&sec@ke99!", "+27839668976");
            assertTrue(user.loginUser("kyl_1", "Ch&8&sec@ke99!"));
        }

        @Test
        public void testLoginFailure() {
            User user = new User("Ahlomela", "Smith", "kyl_1", "Ch&8&sec@ke99!", "+27839668976");
            assertFalse(user.loginUser("wrong", "password"));
        }
    }

}