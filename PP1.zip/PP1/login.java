public class Login {
    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhone;

    public Login(String firstName, String lastName, String username, String password, String cellPhone) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhone = cellPhone;
    }